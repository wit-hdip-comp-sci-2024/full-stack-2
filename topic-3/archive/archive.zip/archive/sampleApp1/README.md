# Friends App 1

This is a sample app for Full Stack 2. 

To install and run, do:

~~~bash
npm install
npm run dev
~~~

