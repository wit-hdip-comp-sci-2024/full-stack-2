# SampleApp1 - React + TypeScript + Vite

This is a sample app to demonstrate data flow patterns in a React app using TypeScript and Vite.

+ Hooks (useState, useEffect) 
+ Side Effect example(async API call)

## Install & Run

In the root directory, run:

```bash
npm install
npm run dev
```
