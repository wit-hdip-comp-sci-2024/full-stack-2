import React from "react";
// import Friend from ....  STATIC DEPENDENCY
const FilteredFriendList = ({list, render}) => {
  const friends = list.map((item) => 
      render(item)
  );
  return <ul>{friends}</ul>;
};

export default FilteredFriendList;
