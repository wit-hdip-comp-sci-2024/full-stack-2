import React from 'react';
import { storiesOf } from '@storybook/react';

import LanguagesStatic from '../components/samples/01_staticComponent';
import LanguagesEnbeddedVars from '../components/samples/02_embeddedVar';
import LanguagesWithProps from '../components/samples/03_props';
import FrameworksIteration from '../components/samples/04_iteration';
import ParentComposition from '../components/samples/05_1_composition';

storiesOf('ReactBasics/Samples', module)
  .add('01 - static component', 
      () =>  <LanguagesStatic/> 
  )
  .add('02 - JSX embedded variables', 
      () =>  <LanguagesEnbeddedVars /> 
  )
  .add('03 - component with props', 
     () => { 
         let list = ['Javascript','Java', 'Python']
         let title = 'Ranked'
         return <LanguagesWithProps languages={list} 
              heading={title} />
     }
  )
  .add('04 - Component collection (Iteration)', 
      () => {    
        let frameworks = [ 
           {name: 'React', url : 'https://facebook.github.io/react/'},
           {name: 'Vue', url : 'https://vuejs.org/'},
           {name: 'Angular', url : 'https://angularjs.org/'} 
        ] ;
        let type = 'JS client-side Web' ;
        return  <FrameworksIteration frams={frameworks} 
           type={type} /> ;
      }
    )
    .add('05 - component composition', 
        () =>  <ParentComposition />
    )
 