# Examples - Routing

This folder contains the routing samples demonstrated in the lectures.
To examine them, first install the dependencies:

~~~
$ npm install
~~~
Start the development server:

~~~
$ npm run dev
~~~

To examine a particular routing feature, edit src/main.tsx to reference 
the relevant sample, e.g.

~~~
import './sample4/';
~~~