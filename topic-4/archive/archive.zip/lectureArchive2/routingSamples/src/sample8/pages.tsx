
export const PublicPage = () => {
  return <h2>Public page</h2>;
};

export const Inbox = () => {
  return <h2>My Indox </h2>;
};

export const Profile = () => {
  return <h2>My Profile </h2>;
};

export const HomePage = () => {
  return <h2>Home page</h2>;
};
