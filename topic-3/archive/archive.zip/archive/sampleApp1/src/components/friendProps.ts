export interface friendProps {
        name: {
            first: string;
            last: string;
        };
        email: string;

}
