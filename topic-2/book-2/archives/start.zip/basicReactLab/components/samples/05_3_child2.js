import React , { Component } from 'react';

export default class Child2 extends Component {
    render() {
        return (
            <div >
                <h2>I'm a child2 component </h2>
            </div>
        );
    }
}