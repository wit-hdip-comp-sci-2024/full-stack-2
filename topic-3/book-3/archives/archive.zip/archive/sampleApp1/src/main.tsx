import ReactDOM from 'react-dom/client'
import FriendsApp from './App';

ReactDOM.createRoot(document.getElementById('root')!).render(
  //<React.StrictMode>
    <FriendsApp />
  //</React.StrictMode>,
)
